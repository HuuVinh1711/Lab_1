/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.TextMind.event;

import com.TextMind.model.Model_Message;

/**
 *
 * @author KHOA
 */
public interface EventMessage {
    public void callMessage(Model_Message message);
}
