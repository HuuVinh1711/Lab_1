/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.TextMind.event;

import javax.swing.Icon;

/**
 *
 * @author KHOA
 */
public interface EventImageView {
    public void viewImage(Icon image);

    public void saveImage(Icon image);
}
