/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.TextMind.swing;

/**
 *
 * @author ducan
 */
public class VerifyGmail {
    String email;
    String codeSend;
    String codeGet;
    public void VerifyAccept(String email){
        
        
    }
}
